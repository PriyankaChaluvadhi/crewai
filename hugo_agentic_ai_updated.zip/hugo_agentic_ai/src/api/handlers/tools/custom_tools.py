from crewai.tools import BaseTool
from typing import List, Optional
import requests
from textwrap import dedent

class HandleHttpError(BaseTool):
    name: str = "Handle HTTP 404 error"
    description: str = "This tool checks the status of the page"

    def check_page_status(self, url):
        try:
            response = requests.get(url, timeout=10)
            print(f"response.status_code = {response.status_code}\n\n")
            return response.status_code
        except requests.exceptions.RequestException as e:
            print(f"Error accessing {url}: {e}")
            return None

    def _run(self, requested_url: str) -> str:

        known_pages = [
            "http://www.hahnemannhospital.com/",
            "http://www.hahnemannhospital.com/Accessibility-Statement.html",
            "http://www.hahnemannhospital.com/Choosing%20Another%20Hospital.html"
            "http://www.hahnemannhospital.com/Closure%20FAQs%20for%20the%20Community.html",
            "http://www.hahnemannhospital.com/Continuing%20your%20Care.html",
            "http://www.hahnemannhospital.com/For-Patients.html",
            "http://www.hahnemannhospital.com/Insurance%20and%20Financial%20Support.html",
            "http://www.hahnemannhospital.com/Nondiscrimination-Notice-and-Language-Assistance-Services.html",
            "http://www.hahnemannhospital.com/Pay-a-Bill.html",
            "http://www.hahnemannhospital.com/Privacy-Notice.html",
            "http://www.hahnemannhospital.com/Request-Records.html",
            "http://www.hahnemannhospital.com/SiteAssets/PAHS%20-%20Final%20Bar%20Date%20Claims%20Form.pdf",
            "http://www.hahnemannhospital.com/SiteAssets/PAHS%20-%20Final%20Bar%20Date%20Notice.pdf",
            "http://www.hahnemannhospital.com/SiteAssets/PAHS%20-%20Final%20Bar%20Date%20Patient%20Notice.pdf",
            "http://www.hahnemannhospital.com/Terms-and-Conditions.html",
            "http://www.hahnemannhospital.com/footer.html",
            "http://www.hahnemannhospital.com/header.html",
            "http://www.hahnemannhospital.com/home.html",
            "http://www.hahnemannhospital.com/login.html",
            "http://cernerhealth.com/oauth/authenticate?redirect_uri=http://cernerhealth.com/saml/sso/response?message_id%3D_55106c14-4a51-4513-8da4-c5adf451f5aa%26issuer%3Dhttp%253A%252F%252Fhahnemannhospital.myhealth-rec.com%252Fsession-api%252Fprotocol%252Fsaml2%252Fmetadata&sign_in_only=on&client_id=21de66db31f54e998d66248c38592d13",
            "http://www.hahnemannhospital.com/contact.html",
        ]

        if requested_url in known_pages:

            root_url = "/".join(requested_url.split("/")[:3])
            root_status = self.check_page_status(root_url)
            print(f"root_status = {root_status}")

            if root_status == 200:
                return (
                    f"The page '{requested_url}' is listed as a known page but is currently returning a 404 error. "
                    "This may be due to the page being renamed, removed, or accidentally deleted."
                )
            else:
                return f"The root site '{root_url}' is not accessible, which may indicate a broader issue."
        else:
            return f"The requested page '{requested_url}' is not in the list of known pages."


class NotifyContentOwner(BaseTool):

    name: str = "Notify the content owner"
    description: str = (
        "This tool notifies the content owner about a page's accessibility issue or site-wide problem."
    )

    def _run(self, requested_url: str, message: str):
        return dedent(
            f"Notification: \n" f"Page: {requested_url}\n" f"Message: {message}"
        )
