from api.contracts.hugo_automation_request import GenericHugoRequest
import re
import warnings
import os
# from api.handlers.crew import FinalCrew
import requests
import logging
import base64
from datetime import datetime, timezone, timedelta
import json
from api.handlers.workflow import Workflow

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")
os.environ["OTEL_SDK_DISABLED"] = "true"

logging.getLogger("crewai").setLevel(logging.CRITICAL)


def get_url_from_description(description):

    # Extract "Application name"
    application_name_match = re.search(r"Application name is (\S+)", description)
    application_name = (
        application_name_match.group(1) if application_name_match else None
    )
    root_url = "http://www." + application_name

    # Extract "GET HTTPS <URL until the next space>"
    log_match = re.search(r"GET(?: HTTPS)? (/[^ ]*)", description)
    url_after_get = log_match.group(0) if log_match else None
    url_after_get_split = url_after_get.split()[-1]
    requested_url = root_url + url_after_get_split
    return requested_url

def get_log_from_description(description):
    log_pattern = r"log=(.+)"
    match = re.search(log_pattern, description, re.DOTALL)

    if match:
        log_entry = match.group(1).strip()
        return log_entry.split("\n")[0]
    else:
        return None

        
def update_snow(template_parameters, file_name):

    # Read the content of the text file
    with open(file_name, "r") as file:
        file_content = file.read()
    # print(f"file_content = {file_content}")

    automation_request_id = template_parameters.get("automation_request_id")
    endpoint = f"http://155.17.173.96:8081/api/automation/{automation_request_id}"

    payload = {
        "work_notes": file_content,
        "automation_status": "Running",
        "incident_status": "Unchanged",
        "automation_state": {},
        "incident_priority": "Unchanged",
        "response_date_time": datetime.now(timezone.utc).isoformat(),
    }

    # Send the in-process update

    print(payload)

    api_username = "API_DEMO"
    api_password = "demo@api"
    auth_string = f"{api_username}:{api_password}"
    encoded_auth_string = base64.b64encode(auth_string.encode("utf-8")).decode("utf-8")

    headers = {
        "Authorization": f"Basic {encoded_auth_string}",
        "Content-Type": "application/json" # "text/plain"
    }

    response = requests.patch(url=endpoint, data=json.dumps(payload), headers=headers)

    # Print the response from the API

    if response.status_code == 200:
        print("Request successful:", response.json())
    else:
        print(
            f"Failed request with status code {response.status_code}: {response.text}"
        )


def handle_run_crew(request: GenericHugoRequest):
    """
    Run the crew.

    """

    requested_url = get_url_from_description(description=request.description)
    print(f"requested_url = {requested_url}\n\n")

    log = get_log_from_description(description=request.description)
    print(f"Log = {log}\n\n")

    inputs = {
        "requested_url": requested_url,
        "log": log,
        }

    flow = Workflow()
    results = flow.kickoff(inputs=inputs)
    print(f"Final Output: {results}")
    filename = "log_test.txt"
    update_snow(template_parameters=request.template_parameters, file_name=filename)
    print(f"request.template_parameters = {request.template_parameters}")