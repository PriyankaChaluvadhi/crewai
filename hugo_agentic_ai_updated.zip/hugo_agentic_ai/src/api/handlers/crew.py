from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task

from api.handlers.tools.custom_tools import HandleHttpError, NotifyContentOwner
from config import AZURE_DEPLOYMENT_NAME, AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION, AZURE_OPENAI_ENDPOINT


OpenAI35kTurbo = LLM(
    model=f"azure/{AZURE_DEPLOYMENT_NAME}",
    api_version=AZURE_OPENAI_API_VERSION,
    api_key=AZURE_OPENAI_API_KEY,
    base_url=AZURE_OPENAI_ENDPOINT
    )


handler_404_error_agent = Agent(
            role="HTTP status code 404 error handler ",
            goal="Handles a 404 error by checking if the requested page is in the list of known pages or not",
            backstory="""You are a diligent error handler agent tasked with handling the case where a requested page returns a 404 error.",
            Check if requested_url is in known_pages and if the root site is accessible and return an appropriate message.""",
            tools=[HandleHttpError()],
            verbose=False,
            llm=OpenAI35kTurbo)

handle_404_error_task = Task(
            description="""Handle the case where a requested page returns a 404 error.
            Requested URL: {requested_url}
            Behavior: -
            1. Check if the requested page is in the `known_pages` list.
            2. If it is, check the accessibility of the root site.
            3. If the root site is accessible, then return explaining that the page is missing.
            4. If the requested page '{requested_url}' is not in the list of known pages and not accessible RESPOND WITH "cyber_agent_help"
            """,
            expected_output="""A message in the following format
            - If the requested url is in the list of known pages and the root site is accessible, then return "The page '{requested_url}' is listed as a known page but is currently returning a 404 error. This may be due to the page being renamed, removed, or accidentally deleted."
            - If the requested url is in the list of known pages and the root site is inaccessible, then return "The root site <link to the root site> is not accessible, which may indicate a broader issue."
            - If the requested url is not in the list of known pages, then return "cyber_agent_help"

            A message explaining whether the issue is page-specific or site-wide or a cyber issue.
            """,
            agent=handler_404_error_agent
        )

ValidityCrew = Crew(
    agents=[handler_404_error_agent], 
    tasks=[handle_404_error_task],
    process=Process.sequential,
    verbose=False,
)

notification_agent = Agent(
    role="Status Notifier",
    goal="Notify the content owner about the accessibility and issues with the site or its pages and the notification message sent.",
    backstory="You are an alert system tasked with informing content owner about the issue.",
    tools=[HandleHttpError()],
    verbose=False,
    llm=OpenAI35kTurbo
)


notification_task = Task(
    description="""Notify the content owner about a page's accessibility issue or site-wide problem.
    Provide the page URL and a descriptive message.

    Page URL: {requested_url}

    Your final answer MUST confirm that the notification was sent successfully.""",
    expected_output="A confirmation message indicating that the content owner has been notified and the content of the notification message sent",
    agent=notification_agent
)

NotificationCrew = Crew(
    agents=[notification_agent], 
    tasks=[notification_task],
    process=Process.sequential,
    verbose=False,
)


cyber_prompt = """
As a Cyber Attack Handler Agent, you are responsible for analyzing web server logs to detect potential cyberattacks. Your task is to classify each request as either Innocent or Malicious and specify the type of attack if applicable.

Classification Guidelines:

1. Innocent: Legitimate user activities, including:
   - Innocent Mistakes: Incorrectly typed URLs, non-existent pages.
   - Legitimate Failed Access: Failed attempts to access valid URLs.

   Examples of Innocent Requests:
   ```
   /sitemap
   /Images/HUH_Logo_PrimaryCare.jpg
   /our-services/neurology
   /search/
   /sitemaps.xml
   ```

2. Malicious: Indicators of potential cyberattacks, such as:
   - SQL Injection: Presence of SQL keywords like `'`, `"`, `OR`, `AND`, `UNION`, etc.
   - Cross-Site Scripting (XSS): Suspicious scripts like `<script>`, `javascript:`.
   - Directory Traversal: Patterns like `../../` for unauthorized directory access.
   - Command Injection: Use of characters like `;`, `&&`, or commands such as `cat`, `ls`.
   - Brute Force: Repeated failed logins from the same IP.
   - Path Spoofing: Requests targeting admin URLs like `/admin`, `/wp-admin`.
   - Denial of Service (DoS): High frequency of requests from the same IP.
   - Unauthorized API Access: Access attempts to secure API endpoints.
   - Unauthorized File Upload: Attempts to upload files without authorization.

   Examples of Malicious Requests:
   ```
   /console
   /login.asp
   /admin/login/index.php
   /..../..../..../..../..../..../..../..../..../windows/win.ini
   /wordpress
   /etc/passwd
   ```

Log Format:
   ```
   [Timestamp] [Service] [Server] [Client IP] [HTTP Method] [URL] [Query String] [Protocol] [Port] [Source IP] [HTTP Version] [User Agent] [Referrer] [Host] [Response Code] [Substatus] [Win32 Status] [Time Taken (ms)] [Bytes Sent] [Bytes Received] [Request Count]
   ```

Valid URL Endpoints:
   Only the URLs listed below are considered valid:
   ```
   /Accessibility-Statement.html
   /Choosing Another Hospital.html
   /Closure FAQs for the Community.html
   /Continuing your Care.html
   /Footer.html
   /For-Patients.html
   /Header.html
   /Home.html
   /Insurance and Financial Support.html
   /Login.html
   /Nondiscrimination-Notice-and-Language-Assistance-Services.html
   /Notice-Of-Privacy-Practices.html
   /Pay-a-Bill.html
   /Privacy-Notice.html
   /Request-Records.html
   /Terms-and-Conditions.html
   ```

Task:
   - Analyze each log entry provided.
   - Classify as Innocent or Malicious.
   - If Malicious, indicate the attack type (e.g., Directory Traversal, Unauthorized File Upload).

Example Classifications:

   Example 1:
   ```
   Input: 2024-06-17 19:13:26 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /plus/carbuyaction.php dopost=return&code=../../ 443 - 62.210.101.198 HTTP/1.1 Mozilla/5.0+(Macintosh;+Intel+Mac+OS+X+10_13_6)+AppleWebKit/537.36+(KHTML,+like+Gecko)+Chrome/83.0.4103.106+Safari/537.36 - http://160.109.69.43:80/plus/carbuyaction.php?dopost=return&code=../../ hahnemannhospital.com 404 0 2 1431 511 115
   Output: Classification: Malicious (Directory Traversal)
   ```

   Example 2:
   ```
   Input: 2024-06-17 05:48:05 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /sitepages/our-services/primary-care.aspx/admin/ckeditor/fileman/php/upload.php - 443 - 141.98.11.166 HTTP/1.0 Mozilla/5.0+(Windows+NT+6.3;+Win64;+x64)+AppleWebKit/537.36+(KHTML,+like+Gecko)+Chrome/75.0.3770.100+Safari/537.36 - - www.hahnemannhospital.com 404 0 2 1431 407 139
   Output: Classification: Malicious (Unauthorized File Upload)
   ```

Output:
   Note: Output should be one liner without any explanation: 
   Classification: Malicious (reason) or Innocent (reason)

Now, analyze the following log entry:
{log}
"""


cyber_agent = Agent(
    role="Cyber Attack Handler Agent",
    goal="Classify a Log as Innocent vs Malicious.",
    backstory=cyber_prompt,
    verbose=False,
    llm=OpenAI35kTurbo
)


cyber_task = Task(
    expected_output="Classify a Log as Innocent vs Malicious.",
    description="Classify a Log as Innocent vs Malicious",
    agent=cyber_agent,
)


cyber_crew = Crew(
    agents=[cyber_agent], 
    tasks=[cyber_task],
    process=Process.sequential,
    verbose=False
)

# Pattern code 

prompt_pattern = """You are an expert in pattern matching from the provided log stream.
Task: 
- Identify stream shows a if log is a Malicious activity.
- If its Malicious responed with "SYSTEM ALERT" else "FALSE"

Malicious: Indicators of potential cyberattacks, such as:
   - SQL Injection: Presence of SQL keywords like `'`, `"`, `OR`, `AND`, `UNION`, etc.
   - Cross-Site Scripting (XSS): Suspicious scripts like `<script>`, `javascript:`.
   - Directory Traversal: Patterns like `../../` for unauthorized directory access.
   - Command Injection: Use of characters like `;`, `&&`, or commands such as `cat`, `ls`.
   - Brute Force: Repeated failed logins from the same IP.
   - Path Spoofing: Requests targeting admin URLs like `/admin`, `/wp-admin`.
   - Denial of Service (DoS): High frequency of requests from the same IP.
   - Unauthorized API Access: Access attempts to secure API endpoints.
   - Unauthorized File Upload: Attempts to upload files without authorization.

Output Format:
  - Output should only be one json output which should represent the logs of a single user.
  - If there are multiple Different url or client ip list all.
  - If logs are not Malicious then type_of_activity is FALSE

  ```json
  {{
    "client_ip_address" : "string",
    "type_of_activity" : "string",
    "invoked_endpoint_url" : "list",
    "client_browser": "string",
    "additional_note": "string" # note for any additional pattern in 2-3 lines
  }}
  ```

Log Stream:
Cyber Agent Comment: {comment}
2024-06-20 14:20:06 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /robots.txt - 443 - 94.130.237.98 HTTP/1.1 Mozilla/5.0+(compatible;+AwarioBot/1.0;++https://awario.com/bots.html) - - www.hahnemannhospital.com 404 0 2 1412 246 138
2024-06-20 14:20:07 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /hahnemannhospital/default.asp - 443 - 94.130.237.98 HTTP/1.1 Mozilla/5.0+(compatible;+AwarioBot/1.0;++https://awario.com/bots.html) - - www.hahnemannhospital.com 404 0 2 1412 292 132
2024-06-20 14:20:18 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /SitePages/Home.aspx - 443 - 94.130.237.98 HTTP/1.1 Mozilla/5.0+(compatible;+AwarioBot/1.0;++https://awario.com/bots.html) - - www.hahnemannhospital.com 404 0 2 1412 282 135
2024-06-20 14:20:19 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /robots.txt - 443 - 85.208.96.195 HTTP/1.1 Mozilla/5.0+(compatible;+SemrushBot/7~bl;++http://www.semrush.com/bot.html) - - www.hahnemannhospital.com 404 0 2 1431 213 37
2024-06-20 14:20:19 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET / refPageViewId=8382881460272d15 443 - 85.208.96.195 HTTP/1.1 Mozilla/5.0+(compatible;+SemrushBot/7~bl;++http://www.semrush.com/bot.html) - - www.hahnemannhospital.com 200 0 0 2160 330 40
2024-06-20 14:20:23 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /SitePages/Closure+FAQs+for+the+Community.aspx - 443 - 94.130.237.98 HTTP/1.1 Mozilla/5.0+(compatible;+AwarioBot/1.0;++https://awario.com/bots.html) - - www.hahnemannhospital.com 404 0 2 1412 316 133
2024-06-20 14:20:36 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /_layouts/15/start.aspx - 443 - 94.130.237.98 HTTP/1.1 Mozilla/5.0+(compatible;+AwarioBot/1.0;++https://awario.com/bots.html) - - www.hahnemannhospital.com 404 0 2 1412 285 133
2024-06-20 14:20:43 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /en-us/ourservices/hospitalservices/pages/financialassistanceprograms.aspx - 443 - 94.130.237.98 HTTP/1.1 Mozilla/5.0+(compatible;+AwarioBot/1.0;++https://awario.com/bots.html) - - www.hahnemannhospital.com 404 0 2 1412 336 140
2024-06-20 14:20:57 W3SVC2 PHSSOHUHPPWEB01 165.136.4.133 GET /SitePages/For-Patients-and-Visitors/Insurance+and+Financial+Support.aspx - 443 - 94.130.237.98 HTTP/1.1 Mozilla/5.0+(compatible;+AwarioBot/1.0;++https://awario.com/bots.html) - - www.hahnemannhospital.com 404 0 2 1412 341 139
{log}
"""

pattern_finder_agent = Agent(
    role="Pattern Indentifier Agent",
    goal="find a pattern in provided Malicious log stream.",
    backstory=prompt_pattern,
    verbose=False,
    llm=OpenAI35kTurbo
)


pattern_finder_task = Task(
    expected_output="Pattern of the provided Malicious log stream",
    description="find a pattern in provided Malicious log stream.",
    agent=pattern_finder_agent,
)


pattern_cerw = Crew(
    agents=[pattern_finder_agent], 
    tasks=[pattern_finder_task],
    process=Process.sequential,
    verbose=False
    )
