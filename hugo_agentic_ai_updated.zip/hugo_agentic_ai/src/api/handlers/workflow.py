from api.handlers.crew import ValidityCrew, cyber_crew, pattern_cerw, NotificationCrew
from crewai.flow.flow import Flow, listen, start, router

from datetime import datetime, timedelta

def write_output(task_name, agent_name, output):
    filename = "log_test.txt"
    with open(filename, "a+") as file:
        file.write(f"Name: {task_name}, agent = {agent_name}, output = {output}\n")
        file.close()


class Workflow(Flow):
    @start()
    def check_down_time(self):
        print(self.state.keys())
        start_time = datetime.now()
        end_time = start_time + timedelta(hours=2)

        log_timestamp_str = " ".join(self.state["log"].split()[:2])
        log_timestamp = datetime.strptime(log_timestamp_str, "%Y-%m-%d %H:%M:%S")
        
        print("Log Timestamp:", log_timestamp)

        if log_timestamp >= start_time and log_timestamp <= end_time:
            print("log during outage of service.")
            write_output(task_name="Checking Down Time.", agent_name="check_down_time", output="log during outage of service.")
            self.state["during_down_time"] = True
        else:
            print("log needs a check from cyber agent.")
            write_output(task_name="Checking Down Time.", agent_name="check_down_time", output="log needs a check from cyber agent.")
            self.state["during_down_time"] = False
        
    @router(check_down_time)
    def conitue_or_exit_1(self):
        if not self.state["during_down_time"]:
            return "continue"
        else:
            return "exit"

     
    @listen("continue") 
    def run_validity_agent(self):
        results = ValidityCrew.kickoff(inputs={"requested_url": self.state["requested_url"]})
        write_output(task_name="Checking if url is valid or not.", agent_name="handler_404_error_agent", output=results.raw)
        if results.raw == "cyber_agent_help":
            self.state["need_cyber_agent_help"] = True
        else:
            self.state["need_cyber_agent_help"] = False    
            
            
    @router(run_validity_agent) 
    def cyber_agent(self):
        if self.state["need_cyber_agent_help"]:
            results = cyber_crew.kickoff(inputs={"log": self.state["log"]})
            write_output(task_name="Check with Cyber Agent", agent_name="cyber_agent", output=results.raw)
            self.state["cyber_agent_output"] = results.raw
            return "call_pattern_agent"
        else:
            write_output(task_name="Check with Cyber Agent", agent_name="cyber_agent", output="Routing to Notification Agent.")
            return "call_notification_agent"

    @listen("call_pattern_agent") 
    def pattern_agent(self, comment):
        if comment != "exit":
            result = pattern_cerw.kickoff(inputs={"log": self.state["log"], "comment": comment})
            write_output(task_name="Checking Pattern in log stream.", agent_name="pattern_agent", output=result.raw)

    @listen("call_notification_agent")    
    def notification_agent(self):
        result = NotificationCrew.kickoff(inputs={"requested_url": self.state["requested_url"]})
        write_output(task_name="sending Notification", agent_name="notification_agent", output=result.raw)    
