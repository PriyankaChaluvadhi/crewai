from pydantic import BaseModel


class GenericHugoRequest(BaseModel):
    description:str
    app_name:str
    template_parameters:dict[str,str]