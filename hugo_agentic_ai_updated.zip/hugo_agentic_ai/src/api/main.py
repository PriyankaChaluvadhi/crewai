

import logging
import traceback
from fastapi import BackgroundTasks, FastAPI, status
from fastapi.responses import JSONResponse

from api.contracts.hugo_automation_request import GenericHugoRequest
from api.handlers.crew_runner import handle_run_crew
from config import API_DESC, API_TITLE, API_VERSION, LOGGER_NAME

logger = logging.getLogger(LOGGER_NAME)

def create_app() -> FastAPI:
    app = FastAPI(title=API_TITLE, description=API_DESC, version=API_VERSION)
    return app

app = create_app()

@app.post("/run_crew")
def copy_files(request:GenericHugoRequest, background_tasks: BackgroundTasks)->JSONResponse:
    try:
        print("new request recieved", request)
        background_tasks.add_task(handle_run_crew, request)
        return JSONResponse(status_code=status.HTTP_200_OK, content=True)
    
    except Exception as ex:
        logger.error(str(ex), stack_info=True)
        traceback.print_exc()
        return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content=str(ex))
    
