import logging
from logging.handlers import TimedRotatingFileHandler

from config import  LOG_LEVEL,LOG_FILE_PATH


def configure_logging(filename:str)->None:
    handler = TimedRotatingFileHandler(filename, 'D', 1, 7)
    fmt = '%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s'
    formatter = logging.Formatter(fmt=fmt, datefmt='%m/%d/%Y %H:%M:%S')
    handler.setFormatter(formatter)
    handler.setLevel(LOG_LEVEL)
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    console.setLevel(logging.INFO)
    logger = logging.getLogger()
    logger.addHandler(console)
    logger.addHandler(handler)
    logger.setLevel(LOG_LEVEL)







# def get_detail_log_file(app_configuration:AppConfiguration):
#     rolling_level = app_configuration.detail_logging_file_rolling_level
#     application_name = app_configuration.application_name
#     application_name= application_name+"_" + str(datetime.date.today().year)
#     if rolling_level.upper() == "MONTH":
#         application_name= application_name+"_"+ datetime.date.today().strftime('%m')
#     application_name = application_name +".csv"
#     return os.path.join(LOG_FOLDER,application_name)



configure_logging(LOG_FILE_PATH)


