from pathlib import Path
import os
import sys
import json 

API_TITLE = "HUGO API's"
API_DESC = "API's for HUGO"
API_VERSION = "1.0.0"
LOGGER_NAME = "hugo_agentic_logger"
GENERIC_CUSTOMER_PLACEHOLDER = "GENERIC"

def get_path(get_src_path = False):
    ext_app_dir = os.getcwd()
    if getattr(sys, 'frozen', False):
        ext_app_dir = sys._MEIPASS
    else:
        if get_src_path is True:
            ext_app_dir = os.path.dirname(__file__)
    return ext_app_dir
WEB_SERVER_PATH  = get_path(False)

def convert_string_to_boolean(value):
    if value is not None and value.lower() in ["true","yes","1","y","t","on"]:
        return True
    return False

def read_config_file():
    config_file_path = os.path.join( get_path(True), "config.json")
    with open(config_file_path, ) as jsonFile:
            return json.load(jsonFile)   

def create_log_folder():
    global LOG_FILE_PATH, LOG_FOLDER
    
    log_folder  = Path(LOG_FILE_PATH)
    os.makedirs(log_folder.parent.absolute(), exist_ok=True)
    LOG_FOLDER = log_folder.parent

def log_config_values():
    
    print(f"LOG_FILE_PATH={LOG_FILE_PATH}")
    print(f"LOG_LEVEL={LOG_LEVEL}")
    print(f"BIND={HOST}")
    print(f"PORT={PORT}")
    print(f"RELOAD={HOT_RELOADING}")
    print(f"USE_DYNAMIC_WORKERS={USE_DYNAMIC_WORKERS}")
    print(f"NO_OF_WORKERS={NO_OF_WORKERS}")
    print(f"LOG_FOLDER={LOG_FOLDER}")
    print(f"WEB_SERVER_PATH={WEB_SERVER_PATH}")
    
    
    

config = read_config_file()
config = read_config_file()
LOG_FOLDER = ""
LOG_FILE_PATH = config["LOG_FILE_NAME"]
LOG_LEVEL = config["LOG_LEVEL"]
HOST = config["HOST"]
PORT = config["PORT"]
HOT_RELOADING = config["HOT_RELOADING"]
USE_DYNAMIC_WORKERS = config["USE_DYNAMIC_WORKERS"]
NO_OF_WORKERS = config["NO_OF_WORKERS"]
WEB_SERVER_PATH  = get_path(False)
TEMPLATE_PATH  = os.path.join(get_path(True),config["TEMPLATE_PATH"])
AZURE_OPENAI_API_KEY = config["AZURE_OPENAI_API_KEY"]
AZURE_DEPLOYMENT_NAME= config["DEPLOYMENT_NAME"]
AZURE_OPENAI_ENDPOINT= config["AZURE_OPENAI_ENDPOINT"]
AZURE_OPENAI_API_VERSION= config["AZURE_OPENAI_API_VERSION"]
AGENT_CONFIG_FILEPATH = "src/config_files/agents.yaml"
TASKS_CONFIG_FILEPATH = "src/config_files/tasks.yaml"


def init():
    create_log_folder()

init()