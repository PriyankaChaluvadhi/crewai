import common.custom_logging
import logging
import uvicorn
from multiprocessing import cpu_count, freeze_support
from api.main import app 
from config import HOST, HOT_RELOADING, LOGGER_NAME, NO_OF_WORKERS, PORT, USE_DYNAMIC_WORKERS



class HugoServer():
    def __init__(self, host:str  , port: int, hot_reloading:bool , no_of_workers:int, use_dynamic_workers:bool  , logger: logging.Logger):
        self.host = host
        self.port = port
        self.no_of_workers = no_of_workers
        self.use_dynamic_workers = use_dynamic_workers
        self.hot_reloading = hot_reloading
        self.logger = logger

    def start_server(self)->None:
        try:
            num_workers = 1
            if self.use_dynamic_workers is True:
                num_workers = int(cpu_count() * 0.75)
            else:
                num_workers = int(self.no_of_workers)
            
            self.logger.critical(f"Starting the application {self.host}:{self.port} using {num_workers} workers - Hot Reload {self.hot_reloading}")
        
            uvicorn.run(
                "api.main:app",
                host=self.host,
                port=self.port,
                reload=self.hot_reloading,
                workers=int(num_workers),
            )
        except Exception as ex:
            self.logger.error("ERROR WHILE STARTING THE APPLICATION")
            self.logger.error(ex)
        

if __name__ == "__main__":
    try:
        freeze_support()  # Needed for pyinstaller for multiprocessing on WindowsOS
        server = HugoServer( HOST, int(PORT), bool(HOT_RELOADING), bool(USE_DYNAMIC_WORKERS), int(NO_OF_WORKERS) , logging.getLogger(LOGGER_NAME))
        server.start_server()
    except Exception as ex:
        print("ERROR WHILE STARTING THE APPLICATION",ex)
        print(ex)
